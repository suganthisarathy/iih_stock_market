package com.estockmarket.company.exception;

public class SQLException {

}
