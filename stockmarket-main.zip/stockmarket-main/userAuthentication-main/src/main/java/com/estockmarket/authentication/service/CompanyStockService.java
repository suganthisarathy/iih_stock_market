package com.estockmarket.authentication.service;

import com.estockmarket.authentication.model.CompanyStock;

public interface CompanyStockService {
	
	public CompanyStock getCompanyDetails(String companyCode); 

}
