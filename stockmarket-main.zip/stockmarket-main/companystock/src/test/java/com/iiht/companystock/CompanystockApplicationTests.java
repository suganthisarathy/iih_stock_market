package com.iiht.companystock;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CompanystockApplicationTests {

	@Test
	void contextLoads() {
	}

}
