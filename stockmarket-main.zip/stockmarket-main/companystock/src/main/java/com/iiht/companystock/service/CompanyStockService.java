package com.iiht.companystock.service;

import com.iiht.companystock.model.CompanyStock;

public interface CompanyStockService {
 
	public CompanyStock getCompanyDetails(String companyCode); 
}
